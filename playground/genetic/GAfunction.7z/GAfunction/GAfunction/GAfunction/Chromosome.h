#pragma once

const int chrSize = 64;

class Chromosome
{
public:
	Chromosome(void);
	~Chromosome(void);

	void SetChromosome( const int& index, const unsigned char& value );
	unsigned char GetChromosome( const int& index );
	void SetFitness( const double& value );
	double GetFitness() const;
	int size() const;
	void Print( const int& index ) const;


private:
	unsigned char chr[ chrSize ];
	double fitness;
};

