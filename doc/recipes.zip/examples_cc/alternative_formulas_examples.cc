#include "test_merton_jump_diff_call.cc"
void alternative_formulas_examples(){
    cout << "-----------------------------" << endl;
    cout << "Alternative formulas " << endl;
    cout << "-----------------------------" << endl;
    test_merton_jump_diff_call();
};
