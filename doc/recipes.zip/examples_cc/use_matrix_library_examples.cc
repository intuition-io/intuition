#include "test_implicit_finite_differences.cc"

void use_matrix_library_examples(){
    test_implicit_finite_differences();
};
