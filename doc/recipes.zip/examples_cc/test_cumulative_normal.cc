#include "normdist.h"

void test_cumulative_normal() {
    cout << " N(0) = " << N(0) << endl;
    cout << " N(0,0,0) = " << N(0,0,0) << endl;
};
