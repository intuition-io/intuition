#include "test_bond_option_gbm_pricing.cc"

void bond_options_examples(){
    cout << "---------------------------------------" << endl;
    cout << "Bond option pricing, simple (GBM) case " << endl;
    cout << "---------------------------------------" << endl;
    test_bond_option_gbm_pricing();
};
