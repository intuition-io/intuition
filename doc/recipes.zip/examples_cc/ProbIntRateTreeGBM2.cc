     vector< vector<double> > tree = interest_rate_trees_gbm_build(0.1,1.02,0.99,3);
     cout << " Interest rate tree: " << endl;
     cout << " Time 0: " << tree[0][0] << endl;
     cout << " Time 1: " << tree[1][0] << "  " << tree[1][1] << endl;
     cout << " Time 2: " << tree[2][0] << "  " << tree[2][1] << "  " << tree[2][2] << endl;
