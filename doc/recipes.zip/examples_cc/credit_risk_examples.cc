#include "fin_recipes.h"

#include "test_credit_risk.cc"

void credit_risk_examples(){
    cout << "------------------------------" << endl;
    cout << "Credit Risk Examples " << endl;
    cout << "------------------------------" << endl;
    test_credit_risk(); 
};
