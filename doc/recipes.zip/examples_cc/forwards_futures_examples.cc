#include "test_futures_price.cc"

void forwards_futures_examples(){
    cout << "---------------------------" << endl;
    cout << "Futures/Forwards pricing   " << endl;
    cout << "---------------------------" << endl;
    test_futures_price();
};
