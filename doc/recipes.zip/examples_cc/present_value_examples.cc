#include "test_present_value.cc"

void present_value_examples(){
    cout << "----------------------------" << endl;
    cout << "Present Value Chapter " << endl;
    cout << "----------------------------" << endl;
    test_present_value();
};
