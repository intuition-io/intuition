     double r0=0.1;
     double u=1.02;  double d=0.99;
     int n=3;
     double q=0.5;
     vector< vector<double> > tree = interest_rate_trees_gbm_build(r0,u,d,n);
     vector<double> cashflows;
     cashflows.push_back(0); cashflows.push_back(10); cashflows.push_back(10); cashflows.push_back(110);
     cout << "Bond price B = " << interest_rate_trees_gbm_value_of_cashflows(cashflows,tree,q);
