     double r0=0.06;
     double u=1.2;  double d=0.9;
     int n=10;
     double q=0.5;
     vector< vector<double> > tree = interest_rate_trees_gbm_build(r0,u,d,n);
     vector<double> cashflows;
     cashflows.push_back(0);
     for (int t=1;t<=9;++t){ cashflows.push_back(6); };
     cashflows.push_back(106);
    cout << "Straight bond price  = " << interest_rate_trees_gbm_value_of_cashflows(cashflows,tree,q) << endl;
    int first_call_time = 6;
    double call_price = 106;
    cout << "Callable bond price = "
	 << interest_rate_trees_gbm_value_of_callable_bond(cashflows,tree,q, first_call_time, call_price) << endl;
