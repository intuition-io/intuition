    double S=100;    double r=0.10;    double time=0.5;
    cout << " futures price = " << futures_price(S,r, time) << endl;
