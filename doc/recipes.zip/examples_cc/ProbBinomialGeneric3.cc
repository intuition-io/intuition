     double S = 100.0;
     double K = 120.0;
     double r = 0.1;
     double sigma = 0.25;
     double time_to_maturity=1.0;
     int steps = 100;
     cout << " binary option price = "
          << option_price_generic_binomial(S,K,payoff_binary_call, r, sigma, time_to_maturity, steps)
          << endl;
