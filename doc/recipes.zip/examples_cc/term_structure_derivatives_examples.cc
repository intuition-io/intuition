#include "test_vasicek_option_pricing.cc"

void term_structure_derivatives_examples(){
    cout << "--------------------------------------" << endl;
    cout << " term structure derivatives examples  " << endl;
    cout << "--------------------------------------" << endl;
    test_vasicek_option_pricing();
}
