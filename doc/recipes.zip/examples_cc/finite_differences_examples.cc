#include "test_explicit_finite_differences.cc"

void finite_differences_examples(){
    cout << "----------------------------" << endl;
    cout << "Finite Differences examples " << endl;
    cout << "----------------------------" << endl;
    test_explicit_finite_differences();
};
