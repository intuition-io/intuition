#include "test_rendleman_bartter_zero_coupon_call.cc"

void binomial_term_structure_models_examples(){
    cout << "---------------------------------------" << endl;
    cout << "Binomial term structure examples " << endl;
    cout << "---------------------------------------" << endl;
    test_rendleman_bartter_zero_coupon_call();    
};
