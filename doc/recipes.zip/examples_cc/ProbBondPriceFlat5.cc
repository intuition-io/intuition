    vector<double> cflows; cflows.push_back(10); cflows.push_back(10); cflows.push_back(110);
    vector<double> times;  times.push_back(1);   times.push_back(2);   times.push_back(3);
    double r=0.09;
    cout << " bonds price    = " <<  bonds_price_discrete(times, cflows, r) << endl;
