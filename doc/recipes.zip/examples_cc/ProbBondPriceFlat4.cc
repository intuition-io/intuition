    vector<double> cflows; cflows.push_back(10); cflows.push_back(10); cflows.push_back(110);
    vector<double> times;  times.push_back(1);   times.push_back(2);   times.push_back(3);
    double r=0.09;
    double B = bonds_price(times, cflows, r);
    cout << " bonds price    = " <<  B << endl;
    cout << " bond duration  = " << bonds_duration(times, cflows, r) << endl;
    cout << " bond convexity =" << bonds_convexity(times, cflows, r) << endl;
    cout << " new bond price = " << bonds_price(times, cflows, 0.08);
