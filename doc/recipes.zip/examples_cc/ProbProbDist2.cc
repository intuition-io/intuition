     cout << " N(0) = " << N(0) << endl;
     cout << " N(0,0,0) = " << N(0,0,0) << endl;
