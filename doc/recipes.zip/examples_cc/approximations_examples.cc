#include "test_baw_approximation_call.cc"
void approximations_examples(){
    cout << "------------------------------------"<< endl;
    cout << "Approximations chapter " << endl;
    cout << "------------------------------------"<< endl;
    test_baw_approximation_call();
};
    
