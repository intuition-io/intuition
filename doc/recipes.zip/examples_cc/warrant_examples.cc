#include "test_warrant_price_adjusted_black_scholes.cc"

void warrant_examples(){
    cout << "----------------------------------------" << endl;
    cout << "Warrant pricing chapter" << endl;
    cout << "----------------------------------------" << endl;
    test_warrant_price_adjusted_black_scholes();
};
