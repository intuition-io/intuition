     double S = 100.0;
     double K = 100.0;
     double r = 0.1;
     double sigma = 0.25;
     double time_to_maturity=1.0;
     int steps = 100;
     cout << " american call price = "
          << option_price_generic_binomial(S,K,payoff_call, r, sigma, time_to_maturity, steps)
          << endl;
     cout << " american put price = "
          << option_price_generic_binomial(S,K,payoff_put, r, sigma, time_to_maturity, steps)
          << endl;
