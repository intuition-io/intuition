 vector<double> cflows; cflows.push_back(-100.0); cflows.push_back(75); cflows.push_back(75);
 vector<double> times; times.push_back(0.0); times.push_back(1); times.push_back(2);
 double r=0.1;
 cout << " Present value, 10 percent discretely compounded interest = "
      << cash_flow_pv_discrete(times, cflows, r) << endl;
