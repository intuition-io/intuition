#include "test_bin_eur_call_ud.cc"

void binomial_examples(){
    cout << "----------------------------" << endl;
    cout << "Binomial Chapter " << endl;
    cout << "----------------------------" << endl;
    test_bin_eur_call_ud();
};
