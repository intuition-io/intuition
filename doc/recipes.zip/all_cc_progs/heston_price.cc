#include <iostream>
#include <cmath>
#include <complex>
using namespace std;
#include "gsl/gsl_integration.h"
struct heston_parms {double K; double x; double r;  double v; double tau;  double kappa; double theta; 
                     double rho; double sigma; double lambda;  int j;};
extern "C"{
double heston_integrand_j(double phi, void *p){  cout << " phi " << phi;
    struct heston_parms* parms = (struct heston_parms*)p;
    double K = (parms->K); double x = (parms->x);
    double v = (parms->v); double r = (parms->r);
    double kappa = (parms->kappa);
    double theta = (parms->theta);
    double rho = (parms->rho);
    double sigma = (parms->sigma);
    double lambda = (parms->lambda);
    double tau = (parms->tau);
    double j = (parms->j);
    double sigma_sqr = pow(sigma,2);
    double uj;    double bj;
    if (j==1){
	uj=0.5;  bj=kappa+lambda-rho*sigma;
    }
    else {
	uj=-0.5; bj=kappa+lambda;
    };
    complex <double> i(0,1);
    double a = kappa*theta;
    complex<double> d  = sqrt( pow(rho*sigma*theta*i-bj,2) - sigma_sqr*(2*uj*phi*i-pow(phi,2)) );
    complex<double> g  = (bj - rho*sigma*phi*i+d)/(bj-rho*sigma*phi*i-d);
    complex<double> C  = r*phi*i*tau+(a/sigma_sqr)*((bj-rho*sigma*phi*i+d)*tau-2.0*log((1.0-g*exp(d*tau))/(1.0-g)));
    complex<double> D  = (bj-rho*sigma*phi*i+d)/sigma_sqr * ( (1.0-exp(d*tau))/(1.0-g*exp(d*tau)) );
    complex<double> f1 = exp(C+D*v+i*phi*x);
    complex<double> F  = exp(-phi*i*log(K))*f1/i*phi;
    double f=real(F);  cout << " f " << f << endl;
    return f;
};};

double heston_Pj(double S, double K, double r, double v, double tau, double sigma, 
                 double kappa, double lambda, double rho, double theta, int j){
    double x=log(S);
    struct heston_parms parms = { K, x, r, v, tau, kappa, theta, rho, sigma, lambda, j};
    size_t n=10000;
    gsl_integration_workspace* w = gsl_integration_workspace_alloc(n);
    gsl_function F;
    F.function = &heston_integrand_j;
    F.params=&parms;
    double result, error;
    gsl_integration_qags(&F,0.0,100.0,1e-7,1e-7,n,w,&result,&error); 
    cout << " result " << result << endl;
    gsl_integration_qagiu(&F,0,1e-7,1e-7,n,w,&result,&error); 
    cout << " result " << result << endl;
    return 0.5 + result/M_PI;
};

double heston_option_price(double S, double K, double r, double v, double tau,
			   double rho,  double kappa,  double lambda,  double theta, double sigma){
    double P1 = heston_Pj(S,K,r,v,tau,sigma,kappa,lambda,rho,theta,1);
    cout << " P1 " << P1 << endl;
    double P2 = heston_Pj(S,K,r,v,tau,sigma,kappa,lambda,rho,theta,2);
    cout << " P2 " << P2 << endl;
    double C=S*P1-K*exp(-r*tau)*P2;
    return C;
};
